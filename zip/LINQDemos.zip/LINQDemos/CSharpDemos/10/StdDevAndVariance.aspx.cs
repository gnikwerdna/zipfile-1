﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_10_StdDevAndVariance : System.Web.UI.Page
{
    protected void btnCompute_Click(object sender, EventArgs e)
    {
        // Split the numbers in the textbox into an array
        var sequenceOfStrings = txtNumbers.Text.Split(",".ToCharArray());

        // Convert the string array into a List of decimals
        var sequenceOfDecimals = new List<decimal>(sequenceOfStrings.Count());
        foreach (var num in sequenceOfStrings)
            sequenceOfDecimals.Add(Convert.ToDecimal(num));
        
        
        lblResults.Text = string.Format("The variance is {0:N2} and the standard deviation is {1:N2}...",
                                            sequenceOfDecimals.Variance(), sequenceOfDecimals.StdDeviation());
    }
}
