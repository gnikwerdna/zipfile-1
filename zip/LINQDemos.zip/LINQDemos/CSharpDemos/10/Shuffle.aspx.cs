﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_10_Shuffle : System.Web.UI.Page
{
    protected void btnShuffle_Click(object sender, EventArgs e)
    {
        var words = txtStrings.Text.Split(" ".ToCharArray());

        lblResults.Text = string.Join(" ", words.Shuffle().ToArray());

        lblRandomWord.Text = words.Shuffle2().Random();
    }
}
