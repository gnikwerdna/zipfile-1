﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_05_PartitioningOps : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Create a Fibonacci object holding the first 10 Fibonacci numbers
        FibonacciCS fib = new FibonacciCS(10);

        // Ignore the first three numbers
        var fibWithFirstThreeRemoved = fib.Skip(3);

        //Could alternatively use the commented out code below
        //var fibWithFirstThreeRemoved = fib.SkipWhile(n => n <= 2);

        var count = fib.Count();
        var avg = fibWithFirstThreeRemoved.Average();
        var sum = fibWithFirstThreeRemoved.Sum();
        var minValue = fibWithFirstThreeRemoved.Min();
        var maxValue = fibWithFirstThreeRemoved.Max();

        Results.Text = string.Format("Some interesting facts about the first {0} Fibonacci numbers: The smallest number is {1}, the largest {2}. The sum of the first 10 numbers is {3}, while the average is {4}! Math is fun!", count, minValue, maxValue, sum, avg);

    }
}
