﻿using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_05_RestrictionOps : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DirectoryInfo dirInfo = new DirectoryInfo(Path.GetDirectoryName(Request.PhysicalPath));
        FileInfo[] fInfo = dirInfo.GetFiles();

        var fileCount = fInfo.Count();
        var totalDiskSpace = fInfo.Sum(f => f.Length);
        var aspxFiles = fInfo.Where(f => Path.GetExtension(f.Name.ToLower()) == ".aspx");
        var aspxFileCount = aspxFiles.Count();
        var aspxFileDiskSpace = aspxFiles.Sum(f => f.Length);

        Results.Text = String.Format("There are {0} total files in the folder, {1} of which are .aspx pages. The total space used is {2:d} bytes, with {3:d} bytes of that used by .aspx pages.", fileCount, aspxFileCount, totalDiskSpace, aspxFileDiskSpace);

    }
}
