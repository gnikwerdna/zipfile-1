﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class CSharpDemos_08_Loading : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string pathToXml = Server.MapPath("~/App_Data/Inventory.xml");
        XElement xml = XElement.Load(pathToXml);

        blInventoryItems.DataSource = from elem in xml.Elements()
                                      select new { NameAndPrice = string.Format("{0} ({1:c})", 
                                                                                    elem.Element("name").Value, 
                                                                                    Convert.ToDecimal(elem.Element("unitPrice").Value)
                                                                                ) };
        blInventoryItems.DataBind();
    }
}
