﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class CSharpDemos_08_ModifyXML : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
            LoadXmlContent();
    }

    private void LoadXmlContent()
    {
        string pathToXml = Server.MapPath("~/App_Data/Inventory.xml");
        XElement xml = XElement.Load(pathToXml);

        blInventoryItems.DataSource = from elem in xml.Elements()
                                      select new
                                      {
                                          NameAndPrice = string.Format("{0} ({1:c})",
                                                                           elem.Element("name").Value,
                                                                           Convert.ToDecimal(elem.Element("unitPrice").Value)
                                                                       )
                                      };
        blInventoryItems.DataBind();

    }

    protected void btnDoublePrices_Click(object sender, EventArgs e)
    {
        string pathToXml = Server.MapPath("~/App_Data/Inventory.xml");
        XElement xml = XElement.Load(pathToXml);

        foreach (XElement item in xml.Elements())
        {
            // First, get the current price
            decimal currentPrice = Convert.ToDecimal(item.Element("unitPrice").Value);

            // Now double it!
            item.SetElementValue("unitPrice", currentPrice * 2);            
        }

        // Finally, save the XML
        xml.Save(pathToXml);

        LoadXmlContent();       // Reload XML content in BulletedList
    }

    protected void btnHalvePrices_Click(object sender, EventArgs e)
    {
        string pathToXml = Server.MapPath("~/App_Data/Inventory.xml");
        XElement xml = XElement.Load(pathToXml);

        foreach (XElement item in xml.Elements())
        {
            // First, get the current price
            decimal currentPrice = Convert.ToDecimal(item.Element("unitPrice").Value);

            // Now halve it!
            item.SetElementValue("unitPrice", currentPrice / 2);
        }

        // Finally, save the XML
        xml.Save(pathToXml);

        LoadXmlContent();       // Reload XML content in BulletedList
    }
}
