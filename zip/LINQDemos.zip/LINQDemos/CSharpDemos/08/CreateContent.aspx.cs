﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class CSharpDemos_08_CreateContent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        XElement inventoryXML =
            new XElement("inventory",
                new XElement("item",
                    new XElement("name", "Teal Trapezoid"),
                    new XElement("itemNumber", "TTTT-T"),
                    new XElement("unitPrice", "8.25"),
                    new XElement("quantity", "414")
                ),
                new XElement("item",
                    new XElement("name", "Puce Parallelogram"),
                    new XElement("itemNumber", "4400-P"),
                    new XElement("unitPrice", "9.99"),
                    new XElement("quantity", "97")
                ),
                new XElement("item",
                    new XElement("name", "Powder Blue Prism"),
                    new XElement("itemNumber", "3110-PBP"),
                    new XElement("unitPrice", "9.50"),
                    new XElement("quantity", "12")
                )
            );

        inventoryXML.Save(Server.MapPath("XMLOutput.xml"));
    }
}
