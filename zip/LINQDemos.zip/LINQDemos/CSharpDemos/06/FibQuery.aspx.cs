﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_06_FibQuery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        FibonacciCS fib = new FibonacciCS(20);

        var oddFibs = from fn in fib
                      where fn % 2 == 1
                      select fn;

        var evenFibs = from fn in fib
                       where fn % 2 == 0
                       orderby fn descending
                       select fn;

        var primeFibs = from fn in fib
                        where IsPrime(fn)
                        orderby fn descending
                        select fn;

        foreach (int num in oddFibs)
            OddNumbers.Text += num + ", ";

        foreach (int num in evenFibs)
            EvenNumbers.Text += num + ", ";

        foreach (int num in primeFibs)
            PrimeNumbers.Text += num + ", ";
    }

    private bool IsPrime(int n)
    {
        if (n == 1)
            return false;

        // See if any numbers between 2 and n/2 divide n
        for (int i = 2; i < n / 2; i++)
            if (n % i == 0)
                return false;

        // If we reach here, we know that n is prime
        return true;
    }
}
