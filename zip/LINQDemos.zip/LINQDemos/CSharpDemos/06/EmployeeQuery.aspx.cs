﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_06_EmployeeQuery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        List<EmployeeCS> emps = new List<EmployeeCS>()
            {
                new EmployeeCS { EmployeeID = 1, Name = "Scott", Salary = 50000M },
                new EmployeeCS { EmployeeID = 2, Name = "Jisun", Salary = 100000M },
                new EmployeeCS { EmployeeID = 3, Name = "Alice", Salary = 75000M },
                new EmployeeCS { EmployeeID = 4, Name = "Sam", Salary = 35000M }
            };

        var HighEarners = from emp in emps
                          where emp.Salary > 60000M
                          orderby emp.Salary descending
                          select new {emp.Name, emp.Salary};


        gvBigBucks.DataSource = HighEarners;
        gvBigBucks.DataBind();
    }
}
