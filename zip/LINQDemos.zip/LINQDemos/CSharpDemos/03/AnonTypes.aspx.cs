﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_03_AnonTypes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //var EmployeeOfTheMonth = new { Name = "Scott", Salary = 50000M };

        //Create a list of EmployeeCS objects
        List<EmployeeCS> Workers = new List<EmployeeCS>() {
                new EmployeeCS() { EmployeeID = 1, Name = "Scott", Salary = 50000M },
                new EmployeeCS() { EmployeeID = 2, Name = "Jisun", Salary = 150000M },
                new EmployeeCS() { EmployeeID = 3, Name = "Alice", Salary = 33000M },
                new EmployeeCS() { EmployeeID = 4, Name = "Sam", Salary = 75000M },
                new EmployeeCS() { EmployeeID = 5, Name = "Dave", Salary = 85000M },
                new EmployeeCS() { EmployeeID = 6, Name = "Marie", Salary = 53000M }
        };

        var TopWorkers = Workers.Where(emp => emp.Salary > 50000M);
        var SimplifiedTopWorkers = TopWorkers.Select(emp => new { Name = emp.Name, Compensation = emp.Salary });

        // Bind SimplifiedTopWorkers to EmployeesGrid
        EmployeesGrid.DataSource = SimplifiedTopWorkers;
        EmployeesGrid.DataBind();
    }
}
