﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_03_LambdaExpression : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Create a list of EmployeeCS objects
        List<EmployeeCS> Workers = new List<EmployeeCS>() {
                new EmployeeCS() { EmployeeID = 1, Name = "Scott", Salary = 50000M },
                new EmployeeCS() { EmployeeID = 2, Name = "Jisun", Salary = 150000M },
                new EmployeeCS() { EmployeeID = 3, Name = "Alice", Salary = 33000M },
                new EmployeeCS() { EmployeeID = 4, Name = "Sam", Salary = 75000M },
                new EmployeeCS() { EmployeeID = 5, Name = "Dave", Salary = 85000M },
                new EmployeeCS() { EmployeeID = 6, Name = "Marie", Salary = 53000M }
        };

        // Bind Workers to EmployeesGrid
        EmployeesGrid.DataSource = Workers;
        EmployeesGrid.DataBind();

        // Bind Workers sorted by salary to EmployeesGrid
        Workers.Sort((emp1, emp2) => emp1.Salary.CompareTo(emp2.Salary));
        SortedEmployeesGrid.DataSource = Workers;
        SortedEmployeesGrid.DataBind();
    }
}
