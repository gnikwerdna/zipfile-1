﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_09_DescendantsAndAscentors : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var root = XElement.Load(Server.MapPath("~/Demos.sitemap"));

        XNamespace siteMapNS = "http://schemas.microsoft.com/AspNet/SiteMap-File-1.0";

        lblNumberOfSiteMapNodeElements.Text = root.Descendants(siteMapNS + "siteMapNode").Count().ToString();

        var mySiteMapNode = root.Descendants(siteMapNS + "siteMapNode")
                                .Where(n => n.Attribute("url") != null && ResolveUrl(n.Attribute("url").Value) == Request.Path)
                                .First();

        if (mySiteMapNode != null)
        {
            blThisNodesDetails.DataSource = mySiteMapNode.Attributes().Select(a => a.Name + ": " + a.Value);
            blThisNodesDetails.DataBind();

            lblNumberOfAncestors.Text = mySiteMapNode.Ancestors(siteMapNS + "siteMapNode").Count().ToString();

            blAncestors.DataSource = mySiteMapNode.Ancestors(siteMapNS + "siteMapNode").Select(n => n.Attribute("title").Value);
            blAncestors.DataBind();
        }
    }
}
