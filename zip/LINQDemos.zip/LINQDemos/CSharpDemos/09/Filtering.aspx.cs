﻿using System;
using System.Globalization;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_09_Filtering : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            // Populate the various DDLs with the calorie values
            var root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"));

            ddlCalories.DataSource = root.Descendants("calories")
                                         .Select(cal => cal.Attribute("total").Value)
                                         .Distinct()
                                         .OrderBy(cal => Convert.ToDecimal(cal));
            ddlCalories.DataBind();


            ddlTotalFat.DataSource = root.Descendants("total-fat")
                                         .Select(fat => fat.Value)
                                         .Distinct()
                                         .OrderBy(fat => Convert.ToDecimal(fat));
            ddlTotalFat.DataBind();

            ddlSodium.DataSource = root.Descendants("sodium")
                                       .Select(sodium => sodium.Value)
                                       .Distinct()
                                       .OrderBy(sodium => Convert.ToDecimal(sodium));
            ddlSodium.DataBind();

            // Finally, show matching food items...
            ShowMatchingFoodItemsUsingWhere();
        }
    }

    protected void btnShowMatchingFoodItems_Click(object sender, EventArgs e)
    {
        ShowMatchingFoodItemsUsingWhere();
    }

    protected void btnShowMatchingFoodItems2_Click(object sender, EventArgs e)
    {
        ShowMatchingFoodItemsUsingXPath();
    }

    private void ShowMatchingFoodItemsUsingWhere()
    {
        var root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"));

        // First, get the results based on the calories/fat/sodium requisites...
        var results =
            root.Elements("food")
                .Where(f => Convert.ToDecimal(f.Element("calories").Attribute("total").Value) <= Convert.ToDecimal(ddlCalories.SelectedValue)
                                &&
                            Convert.ToDecimal(f.Element("total-fat").Value) <= Convert.ToDecimal(ddlTotalFat.SelectedValue)
                                &&
                            Convert.ToDecimal(f.Element("sodium").Value) <= Convert.ToDecimal(ddlSodium.SelectedValue)

                       );

        // Now, let's filter it based on the selected vitamins & minerals
        foreach(ListItem cb in cblVitamins.Items)
            if (cb.Selected)
                results = results.Where(f => f.Element("vitamins").Element(cb.Value).Value != "0").ToList();
        
        foreach (ListItem cb in cblMinerals.Items)
            if (cb.Selected)
                results = results.Where(f => f.Element("minerals").Element(cb.Value).Value != "0").ToList();

        
        // Project the results into the format expected by the GridView...
        var projectedResults = results.Select(f => new
                                                    {
                                                        Name = f.Element("name").Value,
                                                        Calories = Convert.ToDecimal(f.Element("calories").Attribute("total").Value),
                                                        Fat = Convert.ToDecimal(f.Element("total-fat").Value),
                                                        Sodium = Convert.ToDecimal(f.Element("sodium").Value),
                                                        Vitamins = string.Join(", ", f.Element("vitamins").Descendants().Where(v => v.Value != "0").Select(v => string.Format("{0} ({1} mg)", v.Name.ToString().ToUpper(), v.Value)).ToArray()),
                                                        Minerals = string.Join(", ", f.Element("minerals").Descendants().Where(v => v.Value != "0").Select(v => string.Format("{0} ({1} mg)", Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(v.Name.ToString()), v.Value)).ToArray())
                                                    });

        // Bind the results to the GridView
        gvFoodItems.DataSource = projectedResults;
        gvFoodItems.DataBind();
    }

    private void ShowMatchingFoodItemsUsingXPath()
    {
        var root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"));

        // Start by building up the XPath string based on the selected vitamins and minerals
        var vitaminAndMineralXPathPieces = new List<string>(4);
        foreach (ListItem cb in cblVitamins.Items)
            if (cb.Selected)
                vitaminAndMineralXPathPieces.Add(string.Format("count(vitamins/{0}[text() > 0]) > 0", cb.Value));

        foreach (ListItem cb in cblMinerals.Items)
            if (cb.Selected)
                vitaminAndMineralXPathPieces.Add(string.Format("count(minerals/{0}[text() > 0]) > 0", cb.Value));

        var vitaminAndMineralXPath = string.Join(" and ", vitaminAndMineralXPathPieces.ToArray());
        if (vitaminAndMineralXPath.Length > 0)
            vitaminAndMineralXPath = " and " + vitaminAndMineralXPath;

        var xpathQuery = string.Format("/food[calories/@total <= {0} and total-fat/text() <= {1} and sodium/text() <= {2} {3}]",
                                                ddlCalories.SelectedValue, ddlTotalFat.SelectedValue, ddlSodium.SelectedValue, vitaminAndMineralXPath);

        var results = root.XPathSelectElements(xpathQuery);

        // Project the results into the format expected by the GridView...
        var projectedResults = results.Select(f => new
        {
            Name = f.Element("name").Value,
            Calories = Convert.ToDecimal(f.Element("calories").Attribute("total").Value),
            Fat = Convert.ToDecimal(f.Element("total-fat").Value),
            Sodium = Convert.ToDecimal(f.Element("sodium").Value),
            Vitamins = string.Join(", ", f.Element("vitamins").Descendants().Where(v => v.Value != "0").Select(v => string.Format("{0} ({1} mg)", v.Name.ToString().ToUpper(), v.Value)).ToArray()),
            Minerals = string.Join(", ", f.Element("minerals").Descendants().Where(v => v.Value != "0").Select(v => string.Format("{0} ({1} mg)", Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(v.Name.ToString()), v.Value)).ToArray())
        });

        // Bind the results to the GridView
        gvFoodItems.DataSource = projectedResults;
        gvFoodItems.DataBind();

        // Finally, show the XPath expression used...
        lblXPathExpression.Text = "<b>XPath Expression Used:</b> " + xpathQuery;
        lblXPathExpression.Visible = true;
    }
}
