﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_09_ReadingElementsAndAttributes : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"));
        
        // Get the first <food> element...
        var firstFoodElement = root.Element("food");
        if (firstFoodElement != null)
        {
            // Next, get the <food> element's <name> element...
            var nameOfFirstFoodElement = firstFoodElement.Element("name");

            if (nameOfFirstFoodElement != null)
                lblFirstFoodName.Text = nameOfFirstFoodElement.Value;


            // Next, get the total number of calories and calories from fat...
            lblTotalCalories.Text = firstFoodElement.Element("calories").Attribute("total").Value;
            lblFatClories.Text = firstFoodElement.Element("calories").Attribute("fat").Value;
        }

        blFoodNames.DataSource = root.Elements("food")
                                     .Select(f => string.Format("{0} ({1} cal.)",
                                                                f.Element("name").Value,
                                                                f.Element("calories").Attribute("total").Value));
        blFoodNames.DataBind();
    }
}
