﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_01_SOQLanguage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Create an array of integers
        int[] fibNum = { 1, 1, 2, 3, 5, 8, 13, 21, 34 };

        // Use the Count Standard Query Operator to determine how many elements are in the collection
        int totalNumberOfElements = fibNum.Count();

        // Use the Where operator to get the odd Fibonacci numbers and average those
        double averageValue = 
            (from num in fibNum
            where num % 2 == 1
            select num).Average();

        // Output the values...
        Results.Text = String.Format("Of the first {0} elements of Fibonacci sequence the odd numbers have an average value of {1:N2}!", totalNumberOfElements, averageValue);
    }
}
