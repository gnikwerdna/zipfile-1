﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_02_ObjectInitializers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Create an Employee object
        EmployeeCS firstEmp = new EmployeeCS
                            {
                                EmployeeID = 1,
                                Name = "Scott",
                                Salary = 75000M,
                                HireDate = new DateTime(2008, 4, 1),
                                TerminationDate = null
                            };

        // Create a list of employees
        List<EmployeeCS> myEmps = new List<EmployeeCS> {
                    firstEmp,
                    new EmployeeCS { EmployeeID = 2, Name = "Jisun", Salary = 95000M, HireDate = null, TerminationDate = null },
                    new EmployeeCS { EmployeeID = 2, Name = "Alice", Salary = 35000M, HireDate = new DateTime(2008, 9, 1), TerminationDate = null }
            };

        EmployeesGrid.DataSource = myEmps;
        EmployeesGrid.DataBind();
    }
}
