﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_02_ImplicitTyping : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var displayCount = 5;
        var message = "Hello, World!<br />";

        for (int i = 0; i < displayCount; i++)
            Results.Text += message;

        // When declaring an array you need to be a bit more explicit...
        var fibNum = new int[] { 1, 1, 2, 3, 5, 8, 13, 21, 34 };

    }
}
