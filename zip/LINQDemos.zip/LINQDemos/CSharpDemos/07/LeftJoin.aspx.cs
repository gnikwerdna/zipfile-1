﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_07_LeftJoin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var CategoriesAndProducts =
        from category in FauxNorthwind.Data.Categories
            join product in FauxNorthwind.Data.Products on
                category equals product.Category into categoryProducts
        from product in categoryProducts.DefaultIfEmpty()
        select new
        {
            category.CategoryName,
            product
        };

        gvCategoriesAndBooks.DataSource = CategoriesAndProducts;
        gvCategoriesAndBooks.DataBind();
    }
}
