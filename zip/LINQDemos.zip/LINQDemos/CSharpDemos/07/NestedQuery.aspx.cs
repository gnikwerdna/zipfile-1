﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_07_NestedQuery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var CategoriesAndProducts =
            from category in FauxNorthwind.Data.Categories
            select new
            {
                category.CategoryName,
                ProductCount =
                    (from product in FauxNorthwind.Data.Products
                     where product.Category == category
                     select product).Count(),
                Products =
                    (from product in FauxNorthwind.Data.Products
                     where product.Category == category
                     select product)
            };

        //var CategoriesAndProducts = FauxNorthwind.Data.Categories.
        //                                Select(c => new
        //                                    {
        //                                        c.CategoryName,
        //                                        ProductCount = FauxNorthwind.Data.Products.Where(p => p.Category == c).Count(),
        //                                        Products = FauxNorthwind.Data.Products.Where(p => p.Category == c)
        //                                    }
        //                                );


        gvCategoriesAndBooks.DataSource = CategoriesAndProducts;
        gvCategoriesAndBooks.DataBind();
    }
}
