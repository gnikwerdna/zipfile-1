﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_07_GroupByCategory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var CategoriesAndProducts =
                from product in FauxNorthwind.Data.Products
                group product by product.Category into categoryProducts
                select new
                {
                    CategoryName = categoryProducts.Key.CategoryName,
                    ProductCount = categoryProducts.Count(),
                    Products = categoryProducts
                };

        //var CategoriesAndProducts = FauxNorthwind.Data.Products
        //                                .GroupBy(p => p.Category)
        //                                .Select(catGroup => new
        //                                    {
        //                                        CategoryName = catGroup.Key.CategoryName,
        //                                        ProductCount = catGroup.Count(),
        //                                        Products = catGroup
        //                                    }
        //                                );

        gvCategoriesAndBooks.DataSource = CategoriesAndProducts;
        gvCategoriesAndBooks.DataBind();
    }
}
