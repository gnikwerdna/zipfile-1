﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_04_EnumerateFibSequence : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int fibSum = 0;

        FibonacciCS fib = new FibonacciCS(7);

        foreach (int fibValue in fib)
            fibSum += fibValue;

        Results.Text = string.Format("The sum of the first {0} Fibonacci numbers is: {1}.", fib.Capacity, fibSum);
    }
}
