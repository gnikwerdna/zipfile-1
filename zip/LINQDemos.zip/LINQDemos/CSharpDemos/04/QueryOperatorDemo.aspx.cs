﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CSharpDemos_04_QueryOperatorDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        FibonacciCS fib = new FibonacciCS(10);

        Results.Text = string.Format("The sum of the first {0} Fibonacci numbers is: {1}.", fib.Capacity, fib.SummationCS());

        FibGrid.DataSource = fib.SkipUntilSummationSurpassed(6);
        FibGrid.DataBind();


        var oddFibs = fib.Where(x => x % 2 == 1);

        // Try replacing the above oddFib assignment with this one...
        // var oddFibs = fib.Where(x => x % 2 == 1).ToList();

        // Double the size of fib
        fib.Grow();

        OddFibGrid.DataSource = oddFibs;
        OddFibGrid.DataBind();
    }
}
