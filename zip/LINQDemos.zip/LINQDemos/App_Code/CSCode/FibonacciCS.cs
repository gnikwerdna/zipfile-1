﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class FibonacciCS : IEnumerable<int>
{
    private List<int> data = null;

	private FibonacciCS() {}
    public FibonacciCS(int capacity)
    {
        if (capacity < 2)
            throw new ArgumentException("Capacity must be greater than or equal to two.");

        this.Capacity = capacity;

        data = new List<int>(capacity);
        data.Add(1);
        data.Add(1);

        for (int i = 2; i < capacity; i++)
            data.Add(data[i - 2] + data[i - 1]);
    }

    public int Capacity { get; set; }

    public int this[int index]
    {
        get
        {
            return data[index];
        }
    }

    public void Grow()
    {
        int oldSize = this.Capacity;
        int newSize = this.Capacity * 2;

        for (int i = oldSize; i < newSize; i++)
            data.Add(data[i - 2] + data[i - 1]);

        this.Capacity *= 2;
    }

    public IEnumerator<int> GetEnumerator()
    {
        foreach (int number in data)
            yield return number;
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
        foreach (int number in data)
            yield return number;
    }

    //private class FibonacciEnumerator : IEnumerator<int>
    //{
    //    private int index;
    //    private FibonacciCS fibSequence = null;

    //    private FibonacciEnumerator() { }
    //    public FibonacciEnumerator(FibonacciCS sequence)
    //    {
    //        fibSequence = sequence;
    //        index = -1;
    //    }

    //    public int Current
    //    {
    //        get { return fibSequence[index]; }
    //    }

    //    public void Dispose() {}

    //    object System.Collections.IEnumerator.Current
    //    {
    //        get { return fibSequence[index]; }
    //    }

    //    public bool MoveNext()
    //    {
    //        index++;
    //        return index < fibSequence.Capacity;
    //    }

    //    public void Reset()
    //    {
    //        index = -1;
    //    }
    //}
}
