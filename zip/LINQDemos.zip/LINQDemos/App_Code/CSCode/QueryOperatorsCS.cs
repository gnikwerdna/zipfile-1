﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public static class QueryOperatorsCS
{
    public static int SummationCS(this IEnumerable<int> source)
    {
        int total = 0;

        foreach (int num in source)
            total += num;

        return total;
    }

    public static IEnumerable<int> SkipUntilSummationSurpassed(this IEnumerable<int> source, int sum)
    {
        int total = 0;

        foreach (int num in source)
        {
            if (total >= sum)
                yield return num;

            total += num;
        }
    }

    public static double Variance(this IEnumerable<int> source)
    {
        // Compute the average of the sequence
        var avg = source.Average();
        
        // Sum up the difference of each element from the average, squared
        var runningSum = 0.0;
        foreach (int value in source)
            runningSum += (value - avg) * (value - avg);

        // return the runningSum divided by the number of elements
        return runningSum / source.Count();
    }

    public static double StdDeviation(this IEnumerable<int> source)
    {
        // The standard deviation is the square root of the variance
        return Math.Sqrt(source.Variance());
    }

    public static double Variance(this IEnumerable<decimal> source)
    {
        // Compute the average of the sequence
        var avg = source.Average();

        // Sum up the difference of each element from the average, squared
        var runningSum = 0.0M;
        foreach (int value in source)
            runningSum += (value - avg) * (value - avg);

        // return the runningSum divided by the number of elements
        return Convert.ToDouble(runningSum / source.Count());
    }

    public static double StdDeviation(this IEnumerable<decimal> source)
    {
        // The standard deviation is the square root of the variance
        return Math.Sqrt(source.Variance());
    }

    // This function was written by LukeH and can be found online at:
    // http://stackoverflow.com/questions/1651619/optimal-linq-query-to-get-a-random-sub-collection-shuffle/1653204#1653204
    public static IEnumerable<T> Shuffle<T>(this IEnumerable<T> source)
    {
        if (source == null)
            throw new ArgumentNullException("source");

        Random rng = new Random();
        T[] items = source.ToArray();

        for (int n = 0; n < items.Length; n++)
        {
            int k = rng.Next(n, items.Length);
            
            yield return items[k];

            items[k] = items[n];
        }
    }

    public static IEnumerable<T> Shuffle2<T>(this IEnumerable<T> source)
    {
        if (source == null)
            throw new ArgumentNullException("source");

        return source.OrderBy(elem => Guid.NewGuid());
    }

    public static T Random<T>(this IEnumerable<T> source)
    {
        return source.Shuffle().First();
    }
}
