﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FauxNorthwind
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }

    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public Category Category { get; set; }
        public decimal? UnitPrice { get; set; }
        public bool Discontinued { get; set; }
    }

    public static class Data
    {
        public static Category[] Categories =
                {
                    new Category() { CategoryId = 1, CategoryName = "Beverages" },
                    new Category() { CategoryId = 2, CategoryName = "Confections" },
                    new Category() { CategoryId = 3, CategoryName = "Condiments" },
                    new Category() { CategoryId = 4, CategoryName = "Dairy" },
                    new Category() { CategoryId = 5, CategoryName = "Seafood" },
                    new Category() { CategoryId = 6, CategoryName = "Meat/Produce" }
                };

        public static Product[] Products =
                {
                    new Product() { ProductId = 1, ProductName = "Tasty Ale", UnitPrice = 1.95M, Discontinued = false, Category = Categories[0] },
                    new Product() { ProductId = 2, ProductName = "Pastry Puffs", UnitPrice = 4.95M, Discontinued = false, Category = Categories[1] },
                    new Product() { ProductId = 3, ProductName = "Honey Mustard", UnitPrice = 3.50M, Discontinued = false, Category = Categories[2] },
                    new Product() { ProductId = 4, ProductName = "Chai", UnitPrice = 0.95M, Discontinued = false, Category = Categories[0] },
                    new Product() { ProductId = 5, ProductName = "Summer Tea", UnitPrice = 0.55M, Discontinued = false, Category = Categories[0] },
                    new Product() { ProductId = 6, ProductName = "Bigfoot Ale", UnitPrice = 6.95M, Discontinued = false, Category = Categories[0] },
                    new Product() { ProductId = 7, ProductName = "Organic Ketchup", UnitPrice = 3.00M, Discontinued = false, Category = Categories[2] },
                    new Product() { ProductId = 8, ProductName = "Tuna Tuna Tuna", UnitPrice = 14.75M, Discontinued = false, Category = Categories[4] },
                    new Product() { ProductId = 9, ProductName = "Yummy Yogurt", UnitPrice = 1.25M, Discontinued = false, Category = Categories[3] },
                    new Product() { ProductId = 10, ProductName = "Brew Ha Ha", UnitPrice = 5.95M, Discontinued = false, Category = Categories[0] },
                    new Product() { ProductId = 11, ProductName = "Grandma's Cookies", UnitPrice = 2.50M, Discontinued = false, Category = Categories[1] },
                    new Product() { ProductId = 12, ProductName = "Sweet Crackers", UnitPrice = 0.95M, Discontinued = false, Category = Categories[1] },
                    new Product() { ProductId = 13, ProductName = "Shrimp Crackers", UnitPrice = 2.25M, Discontinued = false, Category = Categories[4] },
                    new Product() { ProductId = 14, ProductName = "Squid Cookies", UnitPrice = 1.95M, Discontinued = false, Category = Categories[1] },
                    new Product() { ProductId = 15, ProductName = "Organic Goat Milk", UnitPrice = 3.75M, Discontinued = false, Category = Categories[3] }
                };
    }
}

