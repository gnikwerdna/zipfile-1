﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public static class StringHelpersCS
{
	public static string AddSpacesAfterCaseChangeCS(this string input)
    {
        if (string.IsNullOrEmpty(input))
            return input;

        StringBuilder output = new StringBuilder(input.Length * 2);

        // Add a space before each capitalized letter (except the first)
        for (int i = 0; i < input.Length; i++)
        {
            if (i > 0 && char.IsUpper(input[i]))
                output.Append(" ");

            output.Append(input[i]);
        }

        return output.ToString();
    }
}
