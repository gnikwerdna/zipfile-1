﻿Imports Microsoft.VisualBasic
Imports System.Text
Imports System.Runtime.CompilerServices

Public Module StringExtensionMethodsVB
    <Extension()> _
    Public Function AddSpacesAfterCaseChangeVB(ByVal input As String) As String
        If String.IsNullOrEmpty(input) Then
            Return input
        End If

        Dim output As StringBuilder = New StringBuilder(input.Length * 2)

        ' Add a space before each capitalized letter (except the first)
        For i = 0 To input.Length - 1
            If i > 0 AndAlso Char.IsUpper(input(i)) Then
                output.Append(" ")
            End If

            output.Append(input(i))
        Next

        Return output.ToString()
    End Function
End Module
