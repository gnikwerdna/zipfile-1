﻿Imports Microsoft.VisualBasic

Public Class EmployeeVB
    Private _EmployeeID As Integer
    Public Property EmployeeID() As Integer
        Get
            Return _EmployeeID
        End Get
        Set(ByVal value As Integer)
            _EmployeeID = value
        End Set
    End Property


    Private _Name As String
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property


    Private _Salary As Decimal
    Public Property Salary() As Decimal
        Get
            Return _Salary
        End Get
        Set(ByVal value As Decimal)
            _Salary = value
        End Set
    End Property


    Private _HireDate As Nullable(Of DateTime)
    Public Property HireDate() As Nullable(Of DateTime)
        Get
            Return _HireDate
        End Get
        Set(ByVal value As Nullable(Of DateTime))
            _HireDate = value
        End Set
    End Property


    Private _TerminationDate As Nullable(Of DateTime)
    Public Property TerminationDate() As Nullable(Of DateTime)
        Get
            Return _TerminationDate
        End Get
        Set(ByVal value As Nullable(Of DateTime))
            _TerminationDate = value
        End Set
    End Property

End Class
