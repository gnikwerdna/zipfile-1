﻿Imports Microsoft.VisualBasic

Public Module QueryOperatorsVB
    <System.Runtime.CompilerServices.Extension()> _
    Public Function SummationVB(ByVal source As IEnumerable(Of Integer)) As Integer
        Dim total As Integer = 0

        For Each num As Integer In source
            total += num
        Next

        Return total
    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Public Function VarianceVB(ByVal source As IEnumerable(Of Decimal)) As Double
        ' Compute the average of the sequence
        Dim avg = source.Average()

        ' Sum up the difference of each element from the average, squared
        Dim runningSum As Decimal = 0.0
        For Each value In source
            runningSum += (value - avg) * (value - avg)
        Next

        ' return the runningSum divided by the number of elements
        Return Convert.ToDouble(runningSum / source.Count())
    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Public Function StdDeviationVB(ByVal source As IEnumerable(Of Decimal)) As Double
        ' The standard deviation is the square root of the variance
        Return Math.Sqrt(source.VarianceVB())
    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Public Function ShuffleVB(Of T)(ByVal source As IEnumerable(Of T)) As IEnumerable(Of T)
        If source Is Nothing Then
            Throw New ArgumentNullException("source")
        End If

        Return source.OrderBy(Function(elem) Guid.NewGuid())
    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Public Function RandomVB(Of T)(ByVal source As IEnumerable(Of T)) As T
        Return source.ShuffleVB().First()
    End Function
End Module