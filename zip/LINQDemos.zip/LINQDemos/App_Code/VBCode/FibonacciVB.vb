﻿Imports Microsoft.VisualBasic

Public Class FibonacciVB
    Implements IEnumerable(Of Integer)

    Private data As List(Of Integer)

    Private _Capacity As Integer
    Public Property Capacity() As Integer
        Get
            Return _Capacity
        End Get
        Set(ByVal value As Integer)
            _Capacity = value
        End Set
    End Property

    Private Sub New()
    End Sub

    Public Sub New(ByVal capacity As Integer)
        If capacity < 2 Then
            Throw New ArgumentException("Capacity must be greater than or equal to two.")
        End If

        Me.Capacity = capacity

        data = New List(Of Integer)(capacity)
        data.Add(1)
        data.Add(1)

        For i As Integer = 2 To capacity - 1
            data.Add(data(i - 2) + data(i - 1))
        Next
    End Sub

    Default Public ReadOnly Property Item(ByVal index As Integer) As Integer
        Get
            Return data(index)
        End Get
    End Property

    Public Sub Grow()
        Dim oldSize = Me.Capacity
        Dim newSize = Me.Capacity * 2

        For i As Integer = oldSize To newSize - 1
            data.Add(data(i - 2) + data(i - 1))
        Next

        Me.Capacity *= 2
    End Sub


    Public Function GetEnumerator() As System.Collections.Generic.IEnumerator(Of Integer) Implements System.Collections.Generic.IEnumerable(Of Integer).GetEnumerator
        Return New FibonacciEnumerator(Me)
    End Function

    Public Function GetEnumerator1() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
        Return New FibonacciEnumerator(Me)
    End Function

    Private Class FibonacciEnumerator
        Implements IEnumerator(Of Integer)

        Private index As Integer
        Private fibSequence As FibonacciVB = Nothing

        Private Sub New()
        End Sub

        Public Sub New(ByVal sequence As FibonacciVB)
            fibSequence = sequence
            index = -1
        End Sub

        Public ReadOnly Property Current() As Integer Implements System.Collections.Generic.IEnumerator(Of Integer).Current
            Get
                Return fibSequence(index)
            End Get
        End Property

        Public ReadOnly Property Current1() As Object Implements System.Collections.IEnumerator.Current
            Get
                Return fibSequence(index)
            End Get
        End Property

        Public Function MoveNext() As Boolean Implements System.Collections.IEnumerator.MoveNext
            index += 1
            Return index < fibSequence.Capacity
        End Function

        Public Sub Reset() Implements System.Collections.IEnumerator.Reset
            index = -1
        End Sub

        ' IDisposable
        Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        End Sub

#Region " IDisposable Support "
        ' This code added by Visual Basic to correctly implement the disposable pattern.
        Public Sub Dispose() Implements IDisposable.Dispose
            ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub
#End Region

    End Class
End Class
