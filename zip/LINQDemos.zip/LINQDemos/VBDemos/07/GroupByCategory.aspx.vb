﻿
Partial Class VBDemos_07_GroupByCategory
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CategoriesAndProducts = _
            From product In FauxNorthwind.Data.Products _
             Group product By key = product.Category Into Group _
                Select _
                    CategoryName = key.CategoryName, _
                    ProductCount = Group.Count(), _
                    Products = Group

        'Dim CategoriesAndProducts = FauxNorthwind.Data.Products. _
        '                                        GroupBy(Function(p) p.Category). _
        '                                        Select(Function(catGroup) New With { _
        '                                                   .CategoryName = catGroup.Key.CategoryName, _
        '                                                   .ProductCount = catGroup.Count(), _
        '                                                   .Products = catGroup _
        '                                               } _
        '                                        )


        gvCategoriesAndBooks.DataSource = CategoriesAndProducts
        gvCategoriesAndBooks.DataBind()
    End Sub
End Class
