﻿
Partial Class VBDemos_07_CrossJoin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CategoriesAndProducts = _
           From category In FauxNorthwind.Data.Categories _
            From product In FauxNorthwind.Data.Products _
               Select _
                   category.CategoryName, _
                   product.ProductName, _
                   product.UnitPrice


        gvCategoriesAndBooks.DataSource = CategoriesAndProducts
        gvCategoriesAndBooks.DataBind()
    End Sub
End Class
