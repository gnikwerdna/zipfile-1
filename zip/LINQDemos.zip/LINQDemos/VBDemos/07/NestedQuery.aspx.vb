﻿
Partial Class VBDemos_07_NestedQuery
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CategoriesAndProducts = _
            From category In FauxNorthwind.Data.Categories _
                Select _
                    category.CategoryName, _
                    ProductCount = (From product In FauxNorthwind.Data.Products _
                                    Where product.Category.Equals(category)).Count(), _
                    Products = (From product In FauxNorthwind.Data.Products _
                                    Where product.Category.Equals(category))


        'Dim CategoriesAndProducts = FauxNorthwind.Data.Categories. _
        '                                        Select(Function(c) New With { _
        '                                                   .CategoryName = c.CategoryName, _
        '                                                   .ProductCount = FauxNorthwind.Data.Products.Where(Function(p) p.Category.Equals(c)).Count(), _
        '                                                   .Products = FauxNorthwind.Data.Products.Where(Function(p) p.Category.Equals(c)) _
        '                                               } _
        '                                        )


        gvCategoriesAndBooks.DataSource = CategoriesAndProducts
        gvCategoriesAndBooks.DataBind()
    End Sub
End Class
