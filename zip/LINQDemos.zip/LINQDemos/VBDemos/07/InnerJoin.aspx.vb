﻿
Partial Class VBDemos_07_InnerJoin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CategoriesAndProducts = _
            From category In FauxNorthwind.Data.Categories _
             Join product In FauxNorthwind.Data.Products _
                On category Equals product.Category _
                Select _
                    CategoryName = category.CategoryName, _
                    product

        'Dim CategoriesAndProducts = _
        '        FauxNorthwind.Data.Categories.Join(FauxNorthwind.Data.Products, _
        '                                           Function(c) c, _
        '                                           Function(p) p.Category, _
        '                                           Function(c, p) New With {c.CategoryName, .Product = p} _
        '                                    )

        gvCategoriesAndBooks.DataSource = CategoriesAndProducts
        gvCategoriesAndBooks.DataBind()
    End Sub
End Class
