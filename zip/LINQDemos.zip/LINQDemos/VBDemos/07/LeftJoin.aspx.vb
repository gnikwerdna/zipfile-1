﻿
Partial Class VBDemos_07_LeftJoin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim CategoriesAndProducts = _
            From category In FauxNorthwind.Data.Categories _
             Group Join product In FauxNorthwind.Data.Products _
                On category Equals product.Category Into Group _
            From product In Group.DefaultIfEmpty() _
                Select _
                    CategoryName = category.CategoryName, _
                    product

        gvCategoriesAndBooks.DataSource = CategoriesAndProducts
        gvCategoriesAndBooks.DataBind()
    End Sub
End Class
