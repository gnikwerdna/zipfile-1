﻿
Partial Class VBDemos_05_OrderingOps
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Create a Fibonacci object holding the first 10 Fibonacci numbers
        Dim fib As New FibonacciCS(10)

        AscendingGrid.DataSource = fib.OrderBy(Function(x) x)
        AscendingGrid.DataBind()

        DescendingGrid.DataSource = fib.OrderByDescending(Function(x) x)
        DescendingGrid.DataBind()

    End Sub
End Class
