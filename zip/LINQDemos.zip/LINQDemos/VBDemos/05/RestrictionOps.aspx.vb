﻿Imports System.IO

Partial Class VBDemos_05_RestrictionOps
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim dirInfo As New DirectoryInfo(Path.GetDirectoryName(Request.PhysicalPath))
        Dim fInfo() As FileInfo = dirInfo.GetFiles()

        Dim fileCount = fInfo.Count()
        Dim totalDiskSpace = fInfo.Sum(Function(f) f.Length)
        Dim aspxFiles = fInfo.Where(Function(f) Path.GetExtension(f.Name.ToLower()) = ".aspx")
        Dim aspxFileCount = aspxFiles.Count()
        Dim aspxFileDiskSpace = aspxFiles.Sum(Function(f) f.Length)

        Results.Text = String.Format("There are {0} total files in the folder, {1} of which are .aspx pages. The total space used is {2:d} bytes, with {3:d} bytes of that used by .aspx pages.", fileCount, aspxFileCount, totalDiskSpace, aspxFileDiskSpace)
    End Sub
End Class
