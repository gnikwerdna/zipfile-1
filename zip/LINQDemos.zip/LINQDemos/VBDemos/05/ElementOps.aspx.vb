﻿
Partial Class VBDemos_05_ElementOps
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Create a Fibonacci object holding the first 10 Fibonacci numbers
        Dim fib As New FibonacciVB(10)

        Dim smallestFib = fib.First()
        Dim largestFib = fib.Last()

        Dim thirdFib = fib.ElementAt(2)

        Results.Text = String.Format("Given the first {0} Fibonacci numbers, {1} is the smallest number and {2} the largest. The third Fibonacci number is {3}.", fib.Count(), smallestFib, largestFib, thirdFib)
    End Sub
End Class
