﻿
Partial Class VBDemos_05_PartitioningOps
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Create a Fibonacci object holding the first 10 Fibonacci numbers
        Dim fib As New FibonacciVB(10)

        'Ignore the first three numbers
        Dim fibWithFirstThreeRemoved = fib.Skip(3)

        'Could alternatively use the commented out code below
        'Dim fibWithFirstThreeRemoved = fib.SkipWhile(Function(n) n <= 2)

        Dim count = fib.Count()
        Dim avg = fibWithFirstThreeRemoved.Average()
        Dim sum = fibWithFirstThreeRemoved.Sum()
        Dim minValue = fibWithFirstThreeRemoved.Min()
        Dim maxValue = fibWithFirstThreeRemoved.Max()

        Results.Text = String.Format("Some interesting facts about the first {0} Fibonacci numbers after having removed the first three numbers: The smallest number is {1}, the largest {2}. The sum of the first 10 numbers is {3}, while the average is {4}! Math is fun!", count, minValue, maxValue, sum, avg)

    End Sub
End Class
