﻿
Partial Class VBDemos_05_AggregateOps
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Create a Fibonacci object holding the first 10 Fibonacci numbers
        Dim fib As New FibonacciVB(10)

        Dim count = fib.Count()
        Dim avg = fib.Average()
        Dim sum = fib.Sum()
        Dim minValue = fib.Min()
        Dim maxValue = fib.Max()

        Results.Text = String.Format("Some interesting facts about the first {0} Fibonacci numbers: The smallest number is {1}, the largest {2}. The sum of the first 10 numbers is {3}, while the average is {4}! Math is fun!", count, minValue, maxValue, sum, avg)

    End Sub
End Class
