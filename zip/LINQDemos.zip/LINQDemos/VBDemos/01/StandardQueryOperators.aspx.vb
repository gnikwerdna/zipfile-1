﻿
Partial Class VBDemos_01_StandardQueryOperators
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Create an array of integers
        Dim fibNum() As Integer = {1, 1, 2, 3, 5, 8, 13, 21, 34}

        'Use the Count Standard Query Operator to determine how many elements are in the collection
        Dim totalNumberOfElements As Integer = fibNum.Count()

        'Use the Average Standard Query Operator to determine the average value
        Dim averageValue As Double = fibNum.Average()

        'Output the values...
        Results.Text = String.Format("The first {0} elements of Fibonacci sequence have an average value of {1:N2}!", totalNumberOfElements, averageValue)
    End Sub
End Class
