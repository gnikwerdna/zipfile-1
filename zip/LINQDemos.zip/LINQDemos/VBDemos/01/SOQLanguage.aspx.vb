﻿
Partial Class VBDemos_01_SOQLanguage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Create an array of integers
        Dim fibNum() As Integer = {1, 1, 2, 3, 5, 8, 13, 21, 34}

        'Use the Count Standard Query Operator to determine how many elements are in the collection
        Dim totalNumberOfElements As Integer = fibNum.Count()

        'Compute the average of the odd Fibonacci numbers
        Dim averageValue As Double = _
                Aggregate num In fibNum _
                Where num Mod 2 = 1 _
                Into Average()

        'Output the values...
        Results.Text = String.Format("Of the first {0} elements of Fibonacci sequence the odd numbers have an average value of {1:N2}!", totalNumberOfElements, averageValue)
    End Sub
End Class
