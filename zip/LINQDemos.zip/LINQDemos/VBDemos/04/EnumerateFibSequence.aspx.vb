﻿
Partial Class VBDemos_04_EnumerateFibSequence
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim fibSum As Integer = 0

        Dim fib As New FibonacciVB(7)
        For Each fibValue As Integer In fib
            fibSum += fibValue
        Next

        Results.Text = String.Format("The sum of the first {0} Fibonacci numbers is: {1}.", fib.Capacity, fibSum)
    End Sub
End Class
