﻿
Partial Class VBDemos_04_QueryOperatorDemo
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim fib As New FibonacciVB(10)
        Results.Text = String.Format("The sum of the first {0} Fibonacci numbers is: {1}.", fib.Capacity, fib.SummationVB())

        FibGrid.DataSource = fib.SkipUntilSummationSurpassed(6)
        FibGrid.DataBind()

        Dim oddFibs = fib.Where(Function(x) x Mod 2 = 1)

        ' Try replacing the above oddFib assignment with this one...
        ' Dim oddFibs = fib.Where(Function(x) x Mod 2 = 1).ToList()

        ' Double the size of fib
        fib.Grow()

        OddFibGrid.DataSource = oddFibs
        OddFibGrid.DataBind()
    End Sub
End Class
