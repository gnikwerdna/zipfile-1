﻿
Partial Class VBDemos_06_EmployeeQuery
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim emps As New List(Of EmployeeVB)
        emps.Add(New EmployeeVB() With {.EmployeeID = 1, .Name = "Scott", .Salary = 50000})
        emps.Add(New EmployeeVB() With {.EmployeeID = 2, .Name = "Jisun", .Salary = 100000})
        emps.Add(New EmployeeVB() With {.EmployeeID = 3, .Name = "Alice", .Salary = 75000})
        emps.Add(New EmployeeVB() With {.EmployeeID = 4, .Name = "Sam", .Salary = 35000})

        Dim HighEarners = From emp In emps _
                          Where emp.Salary > 60000 _
                          Order By emp.Salary Descending _
                          Select New With {emp.Name, emp.Salary}


        gvBigBucks.DataSource = HighEarners
        gvBigBucks.DataBind()
    End Sub
End Class
