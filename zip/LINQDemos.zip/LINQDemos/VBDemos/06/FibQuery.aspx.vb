﻿
Partial Class VBDemos_06_FibQuery
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim fib As New FibonacciVB(20)

        Dim oddFibs = From fn In fib _
                      Select fn _
                      Where fn Mod 2 = 1

        Dim evenFibs = From fn In fib _
                       Where fn Mod 2 = 0 _
                       Order By fn Descending _
                       Select fn

        Dim primeFibs = From fn In fib _
                        Select fn _
                        Where IsPrime(fn) _
                        Order By fn Descending


        For Each num As Integer In oddFibs
            OddNumbers.Text &= num & ", "
        Next

        For Each num As Integer In evenFibs
            EvenNumbers.Text &= num & ", "
        Next

        For Each num As Integer In primeFibs
            PrimeNumbers.Text &= num & ", "
        Next
    End Sub

    Private Function IsPrime(ByVal n As Integer) As Boolean
        If n = 1 Then
            Return False
        End If

        ' See if any numbers between 2 and n/2 divide n
        For i As Integer = 2 To n \ 2
            If n Mod i = 0 Then
                Return False
            End If
        Next

        ' If we reach here, we know that n is prime
        Return True
    End Function
End Class
