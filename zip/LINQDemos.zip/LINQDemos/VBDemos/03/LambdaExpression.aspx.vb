﻿
Partial Class VBDemos_03_LambdaExpression
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Create a list of EmployeeVB objects
        Dim Workers As New List(Of EmployeeVB)
        Workers.Add(New EmployeeVB With {.EmployeeID = 1, .Name = "Scott", .Salary = 50000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 2, .Name = "Jisun", .Salary = 150000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 3, .Name = "Alice", .Salary = 33000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 4, .Name = "Sam", .Salary = 75000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 5, .Name = "Dave", .Salary = 85000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 6, .Name = "Marie", .Salary = 53000})

        'Bind Workers to EmployeesGrid
        EmployeesGrid.DataSource = Workers
        EmployeesGrid.DataBind()

        'Bind Workers sorted by salary to EmployeesGrid
        Workers.Sort(Function(emp1, emp2) emp1.Salary.CompareTo(emp2.Salary))
        SortedEmployeesGrid.DataSource = Workers
        SortedEmployeesGrid.DataBind()
    End Sub
End Class
