﻿
Partial Class VBDemos_03_AnonTypes
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim EmployeeOfTheMonth = New With {.Name = "Scott", .Salary = 50000}

        'Create a list of EmployeeVB objects
        Dim Workers As New List(Of EmployeeVB)
        Workers.Add(New EmployeeVB With {.EmployeeID = 1, .Name = "Scott", .Salary = 50000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 2, .Name = "Jisun", .Salary = 150000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 3, .Name = "Alice", .Salary = 33000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 4, .Name = "Sam", .Salary = 75000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 5, .Name = "Dave", .Salary = 85000})
        Workers.Add(New EmployeeVB With {.EmployeeID = 6, .Name = "Marie", .Salary = 53000})

        'Get back a list of Workers who make more than $50,000, projecting the results 
        'onto an anonymous type with two properties: Name and Compensation
        Dim TopWorkers = Workers.Where(Function(emp) emp.Salary > 50000)
        Dim SimplifiedTopWorkers = TopWorkers.Select(Function(emp) New With {.Name = emp.Name, .Compensation = emp.Salary})

        'Bind SimplifiedTopWorkers to EmployeesGrid
        EmployeesGrid.DataSource = SimplifiedTopWorkers
        EmployeesGrid.DataBind()
    End Sub
End Class
