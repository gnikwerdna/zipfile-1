﻿Imports System.Xml.Linq
Imports System.Xml.XPath
Imports System.Globalization
Imports System.Threading

Partial Class VBDemos_09_Filtering
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            ' Populate the various DDLs with the calorie values
            Dim root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"))

            ddlCalories.DataSource = root.Descendants("calories") _
                                         .Select(Function(cal) cal.Attribute("total").Value) _
                                         .Distinct() _
                                         .OrderBy(Function(cal) Convert.ToDecimal(cal))
            ddlCalories.DataBind()

            ddlTotalFat.DataSource = root.Descendants("total-fat") _
                                         .Select(Function(fat) fat.Value) _
                                         .Distinct() _
                                         .OrderBy(Function(fat) Convert.ToDecimal(fat))
            ddlTotalFat.DataBind()

            ddlSodium.DataSource = root.Descendants("sodium") _
                                       .Select(Function(sodium) sodium.Value) _
                                       .Distinct() _
                                       .OrderBy(Function(sodium) Convert.ToDecimal(sodium))
            ddlSodium.DataBind()
            

            ' Finally, show matching food items...
            ShowMatchingFoodItemsUsingWhere()
        End If
    End Sub

    Protected Sub btnShowMatchingFoodItems_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnShowMatchingFoodItems.Click
        ShowMatchingFoodItemsUsingWhere()
    End Sub

    Protected Sub btnShowMatchingFoodItems2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnShowMatchingFoodItems2.Click
        ShowMatchingFoodItemsUsingXPath()
    End Sub

    Private Sub ShowMatchingFoodItemsUsingWhere()
        Dim root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"))

        ' First, get the results based on the calories/fat/sodium requisites...
        Dim results = _
                root.Elements("food") _
                    .Where(Function(f) Convert.ToDecimal(f.Element("calories").Attribute("total").Value) <= Convert.ToDecimal(ddlCalories.SelectedValue) _
                                AndAlso _
                            Convert.ToDecimal(f.Element("total-fat").Value) <= Convert.ToDecimal(ddlTotalFat.SelectedValue) _
                                AndAlso _
                            Convert.ToDecimal(f.Element("sodium").Value) <= Convert.ToDecimal(ddlSodium.SelectedValue) _
                       )

        ' Now, let's filter it based on the selected vitamins & minerals
        For Each cb As ListItem In cblVitamins.Items
            If cb.Selected Then
                results = results.Where(Function(f) f.Element("vitamins").Element(cb.Value).Value <> "0").ToList()
            End If
        Next

        For Each cb As ListItem In cblMinerals.Items
            If cb.Selected Then
                results = results.Where(Function(f) f.Element("minerals").Element(cb.Value).Value <> "0").ToList()
            End If
        Next


        ' Project the results into the format expected by the GridView...
        Dim projectedResults = results.Select(Function(f) New With { _
                                                        .Name = f.Element("name").Value, _
                                                        .Calories = Convert.ToDecimal(f.Element("calories").Attribute("total").Value), _
                                                        .Fat = Convert.ToDecimal(f.Element("total-fat").Value), _
                                                        .Sodium = Convert.ToDecimal(f.Element("sodium").Value), _
                                                        .Vitamins = String.Join(", ", f.Element("vitamins").Descendants().Where(Function(v) v.Value <> "0").Select(Function(v) String.Format("{0} ({1} mg)", v.Name.ToString().ToUpper(), v.Value)).ToArray()), _
                                                        .Minerals = String.Join(", ", f.Element("minerals").Descendants().Where(Function(v) v.Value <> "0").Select(Function(v) String.Format("{0} ({1} mg)", Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(v.Name.ToString()), v.Value)).ToArray()) _
                                                    })

        ' Bind the results to the GridView
        gvFoodItems.DataSource = projectedResults
        gvFoodItems.DataBind()
    End Sub

    Private Sub ShowMatchingFoodItemsUsingXPath()
        Dim root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"))

        ' Start by building up the XPath string based on the selected vitamins and minerals
        Dim vitaminAndMineralXPathPieces As New List(Of String)(4)
        For Each cb As ListItem In cblVitamins.Items
            If cb.Selected Then
                vitaminAndMineralXPathPieces.Add(String.Format("count(vitamins/{0}[text() > 0]) > 0", cb.Value))
            End If
        Next

        For Each cb As ListItem In cblMinerals.Items
            If cb.Selected Then
                vitaminAndMineralXPathPieces.Add(String.Format("count(minerals/{0}[text() > 0]) > 0", cb.Value))
            End If
        Next

        Dim vitaminAndMineralXPath = String.Join(" and ", vitaminAndMineralXPathPieces.ToArray())
        If vitaminAndMineralXPath.Length > 0 Then
            vitaminAndMineralXPath = " and " & vitaminAndMineralXPath
        End If

        Dim xpathQuery = String.Format("/food[calories/@total <= {0} and total-fat/text() <= {1} and sodium/text() <= {2} {3}]", _
                                                ddlCalories.SelectedValue, ddlTotalFat.SelectedValue, ddlSodium.SelectedValue, vitaminAndMineralXPath)

        Dim results = root.XPathSelectElements(xpathQuery)

        ' Project the results into the format expected by the GridView...
        Dim projectedResults = results.Select(Function(f) New With { _
                                                    .Name = f.Element("name").Value, _
                                                    .Calories = Convert.ToDecimal(f.Element("calories").Attribute("total").Value), _
                                                    .Fat = Convert.ToDecimal(f.Element("total-fat").Value), _
                                                    .Sodium = Convert.ToDecimal(f.Element("sodium").Value), _
                                                    .Vitamins = String.Join(", ", f.Element("vitamins").Descendants().Where(Function(v) v.Value <> "0").Select(Function(v) String.Format("{0} ({1} mg)", v.Name.ToString().ToUpper(), v.Value)).ToArray()), _
                                                    .Minerals = String.Join(", ", f.Element("minerals").Descendants().Where(Function(v) v.Value <> "0").Select(Function(v) String.Format("{0} ({1} mg)", Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(v.Name.ToString()), v.Value)).ToArray()) _
                                                })

        ' Bind the results to the GridView
        gvFoodItems.DataSource = projectedResults
        gvFoodItems.DataBind()

        ' Finally, show the XPath expression used...
        lblXPathExpression.Text = "<b>XPath Expression Used:</b> " & xpathQuery
        lblXPathExpression.Visible = True
    End Sub
End Class
