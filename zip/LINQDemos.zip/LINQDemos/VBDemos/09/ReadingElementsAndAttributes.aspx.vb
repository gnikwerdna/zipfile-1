﻿Imports System.Xml.Linq

Partial Class VBDemos_09_ReadingElementsAndAttributes
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim root = XElement.Load(Server.MapPath("~/App_Data/NutritionInfo.xml"))

        ' Get the first <food> element...
        Dim firstFoodElement = root.Element("food")
        If firstFoodElement IsNot Nothing Then
            ' Next, get the <food> element's <name> element...
            Dim nameOfFirstFoodElement = firstFoodElement.Element("name")

            If nameOfFirstFoodElement IsNot Nothing Then
                lblFirstFoodName.Text = nameOfFirstFoodElement.Value
            End If


            ' Next, get the total number of calories and calories from fat...
            lblTotalCalories.Text = firstFoodElement.Element("calories").Attribute("total").Value
            lblFatClories.Text = firstFoodElement.Element("calories").Attribute("fat").Value
        End If

        blFoodNames.DataSource = root.Elements("food") _
                                     .Select(Function(f) String.Format("{0} ({1} cal.)", _
                                                                        f.Element("name").Value, _
                                                                        f.Element("calories").Attribute("total").Value))
        blFoodNames.DataBind()
    End Sub
End Class
