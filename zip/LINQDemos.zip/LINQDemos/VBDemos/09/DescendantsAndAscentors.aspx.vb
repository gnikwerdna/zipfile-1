﻿Imports System.Xml.Linq

Partial Class VBDemos_09_DescendantsAndAscentors
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim root = XElement.Load(Server.MapPath("~/Demos.sitemap"))

        Dim siteMapNS As XNamespace = "http://schemas.microsoft.com/AspNet/SiteMap-File-1.0"

        lblNumberOfSiteMapNodeElements.Text = root.Descendants(siteMapNS + "siteMapNode").Count().ToString()

        Dim mySiteMapNode = root.Descendants(siteMapNS + "siteMapNode") _
                                 .Where(Function(n) n.Attribute("url") IsNot Nothing AndAlso ResolveUrl(n.Attribute("url").Value) = Request.Path) _
                                 .First()

        If mySiteMapNode IsNot Nothing Then
            blThisNodesDetails.DataSource = mySiteMapNode.Attributes().Select(Function(attr) attr.Name.ToString() & ": " & attr.Value.ToString())
            blThisNodesDetails.DataBind()

            'Note: You must use the + operator when combining the namespace and element to query (that is, you cannot use &)
            lblNumberOfAncestors.Text = mySiteMapNode.Ancestors(siteMapNS + "siteMapNode").Count().ToString()

            'Note: You must use the + operator when combining the namespace and element to query (that is, you cannot use &)
            blAncestors.DataSource = mySiteMapNode.Ancestors(siteMapNS + "siteMapNode").Select(Function(n) n.Attribute("title").Value)
            blAncestors.DataBind()
        End If
    End Sub
End Class
