﻿
Partial Class VBDemos_02_ImplicitTyping
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim displayCount = 5
        Dim message = "Hello, World!<br />"

        For i As Integer = 0 To displayCount - 1
            Results.Text &= message
        Next

        'When declaring an array you need to be a bit more explicit...
        Dim fibNum = New Integer() {1, 1, 2, 3, 5, 8, 13, 21, 34}


    End Sub
End Class
