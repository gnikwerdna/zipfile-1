﻿
Partial Class VBDemos_02_ObjectInitializers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Create an Employee object
        Dim firstEmp As New EmployeeVB With { _
                        .EmployeeID = 1, _
                        .Name = "Scott", _
                        .Salary = 75000, _
                        .HireDate = #4/1/2008#, _
                        .TerminationDate = Nothing _
                    }


        ' Create a list of employees
        Dim myEmps = New EmployeeVB() { _
            firstEmp, _
            New EmployeeVB With {.EmployeeID = 2, .Name = "Jisun", .Salary = 95000, .HireDate = Nothing, .TerminationDate = Nothing}, _
            New EmployeeVB With {.EmployeeID = 2, .Name = "Alice", .Salary = 35000, .HireDate = #9/1/2008#, .TerminationDate = Nothing} _
        }

        EmployeesGrid.DataSource = myEmps
        EmployeesGrid.DataBind()
    End Sub
End Class
