﻿
Partial Class VBDemos_02_ExtensionMethods
    Inherits System.Web.UI.Page

    Protected Sub btnProcess_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnProcess.Click
        Results.Text = InputString.Text.AddSpacesAfterCaseChangeVB()
    End Sub
End Class
