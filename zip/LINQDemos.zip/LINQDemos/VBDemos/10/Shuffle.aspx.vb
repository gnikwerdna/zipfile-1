﻿
Partial Class VBDemos_10_Shuffle
    Inherits System.Web.UI.Page

    Protected Sub btnShuffle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnShuffle.Click
        Dim words = txtStrings.Text.Split(" ".ToCharArray())

        lblResults.Text = String.Join(" ", words.ShuffleVB().ToArray())

        lblRandomWord.Text = words.ShuffleVB().RandomVB()
    End Sub
End Class
