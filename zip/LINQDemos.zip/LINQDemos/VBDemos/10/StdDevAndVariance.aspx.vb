﻿
Partial Class VBDemos_10_StdDevAndVariance
    Inherits System.Web.UI.Page

    Protected Sub btnCompute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCompute.Click
        ' Split the numbers in the textbox into an array
        Dim sequenceOfStrings = txtNumbers.Text.Split(",".ToCharArray())

        ' Convert the string array into a List of decimals
        Dim sequenceOfDecimals = New List(Of Decimal)(sequenceOfStrings.Count())
        For Each num In sequenceOfStrings
            sequenceOfDecimals.Add(Convert.ToDecimal(num))
        Next


        lblResults.Text = String.Format("The variance is {0:N2} and the standard deviation is {1:N2}...", _
                                            sequenceOfDecimals.VarianceVB(), sequenceOfDecimals.StdDeviationVB())
    End Sub
End Class
