﻿
Partial Class VBDemos_08_ModifyXML
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadXMLContent()
        End If
    End Sub

    Private Sub LoadXMLContent()
        Dim pathToXml As String = Server.MapPath("~/App_Data/Inventory.xml")
        Dim xml As XElement = XElement.Load(pathToXml)

        blInventoryItems.DataSource = From elem In xml.Elements() _
                                      Select New With {.NameAndPrice = String.Format("{0} ({1:c})", _
                                                                                    elem.Element("name").Value, _
                                                                                    Convert.ToDecimal(elem.Element("unitPrice").Value) _
                                                                                )}
        blInventoryItems.DataBind()
    End Sub

    Protected Sub btnDoublePrices_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDoublePrices.Click
        Dim pathToXml As String = Server.MapPath("~/App_Data/Inventory.xml")
        Dim xml As XElement = XElement.Load(pathToXml)

        For Each item As XElement In xml.Elements()
            ' First, get the current price
            Dim currentPrice As Decimal = Convert.ToDecimal(item.Element("unitPrice").Value)

            ' Now double it!
            item.SetElementValue("unitPrice", currentPrice * 2)
        Next

        ' Finally, save the XML
        xml.Save(pathToXml)

        LoadXMLContent()       ' Reload XML content in BulletedList
    End Sub

    Protected Sub btnHalvePrices_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHalvePrices.Click
        Dim pathToXml As String = Server.MapPath("~/App_Data/Inventory.xml")
        Dim xml As XElement = XElement.Load(pathToXml)

        For Each item As XElement In xml.Elements()
            ' First, get the current price
            Dim currentPrice As Decimal = Convert.ToDecimal(item.Element("unitPrice").Value)

            ' Now double it!
            item.SetElementValue("unitPrice", currentPrice / 2)
        Next

        ' Finally, save the XML
        xml.Save(pathToXml)

        LoadXMLContent()       ' Reload XML content in BulletedList
    End Sub
End Class
