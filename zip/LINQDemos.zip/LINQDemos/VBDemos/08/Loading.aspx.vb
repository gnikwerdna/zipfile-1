﻿
Partial Class VBDemos_08_Loading
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim pathToXml As String = Server.MapPath("~/App_Data/Inventory.xml")
        Dim xml As XElement = XElement.Load(pathToXml)

        blInventoryItems.DataSource = From elem In xml.Elements() _
                                      Select New With {.NameAndPrice = String.Format("{0} ({1:c})", _
                                                                                    elem.Element("name").Value, _
                                                                                    Convert.ToDecimal(elem.Element("unitPrice").Value) _
                                                                                )}
        blInventoryItems.DataBind()
    End Sub
End Class
