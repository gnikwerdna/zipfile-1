﻿
Partial Class VBDemos_08_CreateContent
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim inventoryXML As XElement = _
            New XElement("inventory", _
                New XElement("item", _
                    New XElement("name", "Teal Trapezoid"), _
                    New XElement("itemNumber", "TTTT-T"), _
                    New XElement("unitPrice", "8.25"), _
                    New XElement("quantity", "414") _
                ), _
                New XElement("item", _
                    New XElement("name", "Puce Parallelogram"), _
                    New XElement("itemNumber", "4400-P"), _
                    New XElement("unitPrice", "9.99"), _
                    New XElement("quantity", "97") _
                ), _
                New XElement("item", _
                    New XElement("name", "Powder Blue Prism"), _
                    New XElement("itemNumber", "3110-PBP"), _
                    New XElement("unitPrice", "9.50"), _
                    New XElement("quantity", "12") _
                ) _
            )

        'You can alternatively use VB's XML Literal syntax!
        'Dim inventoryXML As XElement = _
        '    <inventory>
        '        <item>
        '            <name>Teal Trapezoid</name>
        '            <itemNumber>TTTT-T</itemNumber>
        '            <unitPrice>8.25</unitPrice>
        '            <quantity>414</quantity>
        '        </item>
        '        <item>
        '            <name>Puce Parallelogram</name>
        '            <itemNumber>4400-P</itemNumber>
        '            <unitPrice>9.99</unitPrice>
        '            <quantity>97</quantity>
        '        </item>
        '        <item>
        '            <name>Powder Blue Prism</name>
        '            <itemNumber>3110-PBP</itemNumber>
        '            <unitPrice>9.50</unitPrice>
        '            <quantity>12</quantity>
        '        </item>
        '    </inventory>

        inventoryXML.Save(Server.MapPath("XMLOutput.xml"))
    End Sub
End Class
