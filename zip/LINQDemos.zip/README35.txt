To run these demos, open the folder as a file-system-based website project in Visual Studio 2008.

   ****************
   Note: These demos contain code or concepts specific to ASP.NET version 3.5. Consequently you will need to use Visual Studio 2008 or beyond. For more information on what's new in 3.5, see: http://www.4guysfromrolla.com/articles/112107-1.aspx
   ****************

Don't have Visual Studio 2008? You can download a free "Express" version:
http://www.microsoft.com/express/Web


	Scott Mitchell
	mitchell@4guysfromrolla.com
	Blog: http://ScottOnWriting.NET
	
